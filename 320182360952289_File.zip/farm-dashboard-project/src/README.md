How To Run

to run this code install eclipse and jdk 8

- clone this repository into `farm-dashboard-prototype`
- open Eclipse
- select File
-Import Existing Projects into Workspace Next Browse
- locate the cloned `farm-dashboard project` directory then select open it
- select Finish
- click the green play button labeled "Run" on the upper icon bar